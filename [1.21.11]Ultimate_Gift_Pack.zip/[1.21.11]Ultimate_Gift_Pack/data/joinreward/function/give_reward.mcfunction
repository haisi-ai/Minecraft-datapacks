# ============================================
# 给当前玩家发放奖励
# ============================================

# 开始发放
tellraw @s ["",{"text":"[系统] ","color":"gold"},{"text":"正在发放礼包...","color":"green"}]

# 4. 给予所有奖励
function joinreward:rewards/weapons
function joinreward:rewards/tools
function joinreward:rewards/food
function joinreward:rewards/special
function joinreward:rewards/armor

# 5. 显示消息（只给当前玩家）
function joinreward:messages

# 6. 同时设置计分板（用于显示状态）
scoreboard players set @s joinreward.given 1

# 完成消息
tellraw @s ["",{"text":"✅ ","color":"green"},{"text":"礼包发放完成！","color":"white"}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1