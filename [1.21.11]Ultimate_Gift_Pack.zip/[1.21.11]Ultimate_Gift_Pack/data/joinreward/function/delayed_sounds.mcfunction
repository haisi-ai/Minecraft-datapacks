# 延迟音效
execute as @s at @s run playsound minecraft:block.note_block.bell player @s ~ ~ ~ 0.7 1.8
execute as @s at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 2.0