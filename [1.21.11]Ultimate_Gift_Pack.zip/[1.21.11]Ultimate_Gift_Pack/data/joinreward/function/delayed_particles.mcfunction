# 延迟粒子特效
execute as @s at @s run particle minecraft:dragon_breath ~ ~1.5 ~ 0.6 0.4 0.6 0.04 15
execute as @s at @s run particle minecraft:heart ~ ~1 ~ 0.3 0.4 0.3 0.02 8