# messages.mcfunction - 豪华版

# 私人消息
tellraw @s ["",{"text":"\n═══════════════════════════════\n","color":"dark_gray"}]
tellraw @s ["",{"text":"         🎁 欢迎加入！\n","color":"gold","bold":true}]
tellraw @s ["",{"text":"═══════════════════════════════\n","color":"dark_gray"}]
tellraw @s ["",{"text":"  • 全套下界合金装备","color":"red"}]
tellraw @s ["",{"text":"  • 强力附魔武器","color":"red"}]
tellraw @s ["",{"text":"  • 高效采集工具","color":"yellow"}]
tellraw @s ["",{"text":"  • 丰富食物资源","color":"gold"}]
tellraw @s ["",{"text":"  • 实用特殊物品","color":"aqua"}]
tellraw @s ["",{"text":"═══════════════════════════════\n","color":"dark_gray"}]

# 标题显示 # 淡入10tick，停留60tick，淡出10tick
title @s times 10 60 10 
title @s title {"text":"🌟 传奇开始 🌟","color":"gold","bold":true}
title @s subtitle {"text":"至尊礼包已降临","color":"#FFD700","bold":true,"italic":true}

# ========== 豪华音效组合 ==========
# 使用 execute as @s at @s 确保100%播放

# 1. 开场音（空灵神秘）
execute as @s at @s run playsound minecraft:block.beacon.activate player @s ~ ~ ~ 0.8 0.8

# 2. 主音效（史诗感）
execute as @s at @s run playsound minecraft:music_disc.11 player @s ~ ~ ~ 0.6 1.5
execute as @s at @s run playsound minecraft:item.trident.thunder player @s ~ ~ ~ 0.7 1.2

# 3. 物品出现音（清脆）
execute as @s at @s run playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 1 1
execute as @s at @s run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.9 1.3

# 4. 完成音（满足感）
execute as @s at @s run playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
execute as @s at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.2

# 5. 结尾音（余韵）
schedule function joinreward:delayed_sounds 15t

# ========== 豪华粒子特效组合（1.21+正确格式）==========

# 1. 基础光环
execute as @s at @s run particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.03 25
execute as @s at @s run particle minecraft:firework ~ ~1 ~ 0.3 0.5 0.3 0.02 20

# 兼容所有版本的豪华粒子特效

# 1. 基础效果（100%兼容）
execute as @s at @s run particle minecraft:end_rod ~ ~1 ~ 0.4 0.6 0.4 0.03 30
execute as @s at @s run particle minecraft:firework ~ ~1 ~ 0.3 0.5 0.3 0.02 25

# 2. 彩色效果（使用兼容粒子）
execute as @s at @s run particle minecraft:glow_squid_ink ~ ~1.5 ~ 0.5 0.3 0.5 0.02 25
execute as @s at @s run particle minecraft:glow_squid_ink ~ ~1.5 ~ 0.5 0.3 0.5 0.02 25
execute as @s at @s run particle minecraft:sculk_charge_pop ~ ~1.5 ~ 0.5 0.3 0.5 0.04 18
execute as @s at @s run particle minecraft:wax_on ~ ~1.5 ~ 0.4 0.3 0.4 0.02 15
execute as @s at @s run particle minecraft:witch ~ ~1.2 ~ 0.5 0.3 0.5 0.03 15

# 3. 特殊效果
execute as @s at @s run particle minecraft:enchanted_hit ~ ~1 ~ 0.5 0.4 0.5 0.06 12
execute as @s at @s run particle minecraft:totem_of_undying ~ ~1.2 ~ 0.4 0.5 0.4 0.04 10

# 4. 地面光环
execute as @s at @s run particle minecraft:portal ~ ~0.2 ~ 1.0 0.1 1.0 0.1 40
execute as @s at @s run particle minecraft:dragon_breath ~ ~0.3 ~ 0.8 0.1 0.8 0.08 25

# 5. 延迟特效（持续效果）
schedule function joinreward:delayed_particles 5t
schedule function joinreward:more_particles 10t

# ========== 视觉特效 ==========
effect give @s minecraft:glowing 10 0 true
effect give @s minecraft:slow_falling 8 0 true
effect give @s minecraft:regeneration 5 1 true

# 发光边框（自定义RGB颜色）
effect give @s minecraft:glowing 10 0 true