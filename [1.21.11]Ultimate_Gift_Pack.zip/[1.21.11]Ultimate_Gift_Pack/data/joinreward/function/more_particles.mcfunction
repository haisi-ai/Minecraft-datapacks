# 更多粒子
execute as @s at @s run particle minecraft:totem_of_undying ~ ~1.2 ~ 0.4 0.5 0.4 0.03 12
execute as @s at @s run particle minecraft:crimson_spore ~ ~1 ~ 0.5 0.3 0.5 0.02 10

# 最后一波
schedule function joinreward:final_effects 5t