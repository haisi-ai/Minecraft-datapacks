# tick.mcfunction

# 一行解决：不是1就发放
execute as @a unless score @s joinreward.given matches 1 run function joinreward:give_reward