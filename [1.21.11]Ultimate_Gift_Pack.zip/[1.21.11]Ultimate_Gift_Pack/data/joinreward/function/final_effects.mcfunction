# 最终效果
execute as @s at @s run particle minecraft:explosion ~ ~1 ~ 0.2 0.3 0.2 0 5
execute as @s at @s run playsound minecraft:entity.firework_rocket.blast player @s ~ ~ ~ 0.5 1.5