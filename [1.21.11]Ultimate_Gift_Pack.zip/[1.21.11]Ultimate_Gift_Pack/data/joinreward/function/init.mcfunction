# 初始化函数 - 只执行一次
# 在load.json中调用

# 创建计分板
scoreboard objectives add joinreward.given dummy "奖励状态"

# 系统加载消息
tellraw @a[limit=1] ["",{"text":"[奖励系统] ","color":"gold"},{"text":"已成功加载","color":"green"}]
tellraw @a[limit=1] ["",{"text":"• 新玩家加入自动获得礼包","color":"gray"}]
tellraw @a[limit=1] ["",{"text":"• 系统每tick检测新玩家","color":"gray"}]